﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<string> studentNames = new List<string>();

        while (true)
        {
            Console.WriteLine("\n1. Add Student");
            Console.WriteLine("2. View Students");
            Console.WriteLine("3. Exit");
            Console.Write("Choose your option : ");
            string choice = Console.ReadLine();

            if (choice == "1")
            {
                Console.Write("Enter student name: ");
                string name = Console.ReadLine();
                studentNames.Add(name);
                Console.WriteLine("Student name added.");
            }
            else if (choice == "2")
            {
                Console.WriteLine("\nStudents:");
                foreach (string student in studentNames)
                {
                    Console.WriteLine(student);
                }
            }
            else if (choice == "3")
            {
                break;
            }
            else
            {
                Console.WriteLine("The name is not in the list.");
            }
        }
    }
}
