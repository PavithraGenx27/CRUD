﻿internal class student
{
}