﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static Dictionary<string, double> grades = new() { ["Alice"] = 85, ["Bob"] = 92, ["Charlie"] = 70 };

    static void Main()
    {
        Console.Write("1.Search 2.Filter: ");
        var c = Console.ReadLine();
        if (c == "1") Show(grades.Where(g => g.Key.ToLower().Contains(Read("Name: ").ToLower())));
        else if (c == "2")
        {
            double min = Get("Min: "), max = Get("Max: ");
            Show(grades.Where(g => g.Value >= min && g.Value <= max));
        }
    }

    static string Read(string msg) { Console.Write(msg); return Console.ReadLine(); }
    static double Get(string msg) => double.TryParse(Read(msg), out var v) ? v : Get(msg);
    static void Show(IEnumerable<KeyValuePair<string, double>> data) =>
        Console.WriteLine(data.Any() ? string.Join("\n", data.Select(g => $"{g.Key}: {g.Value}")) : "No matches.");
}
