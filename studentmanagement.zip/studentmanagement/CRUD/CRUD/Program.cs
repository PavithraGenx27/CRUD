﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        var grades = new Dictionary<string, double>();

        while (true)
        {
            Console.WriteLine("\n1. Add Grade\n2. View Grades\n3. Search Grade\n4. Exit");
            Console.Write("Choose option: ");
            switch (Console.ReadLine())
            {
                case "1":
                    AddGrade(grades);
                    break;
                case "2":
                    ViewGrades(grades);
                    break;
                case "3":
                    SearchGrade(grades);
                    break;
                case "4":
                    Console.WriteLine("Goodbye!");
                    return;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }

    static void AddGrade(Dictionary<string, double> grades)
    {
        Console.Write("Student name: ");
        string name = Console.ReadLine();

        Console.Write("Grade (0-100): ");
        if (double.TryParse(Console.ReadLine(), out double grade))
        {
            grades[name] = grade;
            Console.WriteLine("Grade added.");
        }
        else
        {
            Console.WriteLine("Invalid grade.");
        }
    }

    static void ViewGrades(Dictionary<string, double> grades)
    {
        if (grades.Count == 0)
        {
            Console.WriteLine("No grades entered.");
            return;
        }

        foreach (var entry in grades)
            Console.WriteLine($"{entry.Key}: {entry.Value}");
    }

    static void SearchGrade(Dictionary<string, double> grades)
    {
        Console.Write("Enter name: ");
        string name = Console.ReadLine();

        if (grades.TryGetValue(name, out double grade))
            Console.WriteLine($"{name}'s grade: {grade}");
        else
            Console.WriteLine("Student not found.");
    }
}
zxzzz2