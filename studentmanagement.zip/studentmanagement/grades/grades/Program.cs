﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        var grades = new Dictionary<string, double>();

        grades["Hema"] = 85.5;
        grades["Babu"] = 92.0;
        grades["Chirsty"] = 78.3;

        foreach (var kvp in grades)
            Console.WriteLine($"{kvp.Key}: {kvp.Value}");
    }
}
